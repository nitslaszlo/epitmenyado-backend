export default interface TokenData {
    token: string;
    expiresIn: number;
}
