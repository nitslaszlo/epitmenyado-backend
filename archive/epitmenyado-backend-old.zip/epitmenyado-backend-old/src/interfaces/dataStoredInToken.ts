export default interface DataStoredInToken {
    _id: string;
}
